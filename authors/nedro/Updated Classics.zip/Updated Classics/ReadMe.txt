Updated Classics

These are classic maps I stumbled on in recent years that were unique but needed a little help. I took it upon myself to revise them. Oil is the Key  needed very little editing while Rivers needed a lot. Rivers BNE offers something very different than the more popular water maps like High Seas Combat and Fierce Ocean Combat. 

-Nedro